# Wireframes — Honda CBR650R

[Comparer les trois sites](./index.html)

| Proposition | Direction | Prévisualisation |
| --- | --- | --- |
| Redline | Sportive, sombre et immersive | [Ouvrir](./redline.html) |
| Swiss Ride | Claire, narrative et aérienne | [Ouvrir](./alpine.html) |
| Detail Lab | Showroom, structurée et précise | [Ouvrir](./lab.html) |

## Interaction commune

Le scroll contrôle une vraie caméra 3D : rotation autour de la moto, zoom sur les détails et dézoom final. La navigation permet de rejoindre un chapitre directement.

## Ouverture

Extraire le ZIP et ouvrir `index.html` dans un navigateur. Tous les fichiers doivent rester dans le même dossier. Aucun serveur ni installation nécessaire. Le chargement initial traite un modèle détaillé d’environ 34 Mo. Les maquettes fonctionnent hors ligne ; les liens Honda et les liens de crédit nécessitent une connexion.

## Crédit

Modèle « Honda CBR650R » par [VTX](https://sketchfab.com/VTX_car), disponible sur [Sketchfab](https://sketchfab.com/3d-models/honda-cbr650r-b9ec190f902d4180aa527659af3f5089), sous [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/).

Adaptations : présentation web et cadrages de caméra ; matériaux ajustés pour une livrée rouge et noire. Les adaptations du modèle restent sous la même licence. Le modèle comporte des personnalisations et ne sert pas de preuve des caractéristiques de série. Projet scolaire indépendant, non officiel Honda.

## Captures pour le Markdown

### Redline

![Accueil Redline](./redline-desktop.png)

### Swiss Ride

![Accueil Swiss Ride](./alpine-desktop.png)

### Detail Lab

![Accueil Detail Lab](./lab-desktop.png)
